
public class TNode
{
    TNode left;
    int data;
    TNode right;
    
    public TNode(TNode left, int data, TNode right){
        
        this.left = left;
        this.data = data;
        this.right = right;
        
    }
}


public class TreeProgram
{
    
   public static void main(){
    BST b1 = new BST();
    
    b1.add(7);
    b1.add(9);
    b1.add(17);
    b1.add(2);
    b1.add(1);
    b1.add(79);
    b1.printall();
    System.out.println("MIN = "+b1.min());
    System.out.println("MAX = "+b1.max());
    System.out.println(b1.search(17).data);
    
   }
}

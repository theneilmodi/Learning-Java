
/**
 * Write a description of class InvisibleDeck here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class InvisibleDeck
{
    // instance variables - replace the example below with your own
    public static void main(){
     
        int val = 1;
        String suit1 = "Clubs";
        String suit2 = "Diamonds";
        
     while(val <= 2){  
         
        for(int i = 1; i<=13; i++){
            
            
            
            System.out.println(14-i + " " + suit1 + " and " + i + " " + suit2);
            
        }
        
        val++;
        suit1 = "Hearts";
        suit2 = "Spades";
        System.out.println("\n");
     }
    }
}

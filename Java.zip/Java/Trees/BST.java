
/**
 * Binary Search Tree
 */
public class BST
{

    private TNode root;
    
    public void add(int n){
        
        if(root == null) root = new TNode(null,n,null);
        else{
          
            TNode p = null; 
            TNode q = root;
            
            
            while(q!=null){
                
                p = q;
                
                if(n < q.data)
                  q = q.left;  
  
                else
                 q = q.right;     
                
            }
            
            if(n < p.data) p.left = new TNode(null,n,null);
            else p.right = new TNode(null, n, null);
        }
    }
    
    public void printall(){
       
        printInOrder(root);
        
    }
    
    private void printInOrder(TNode r){
        
        if(r == null) return;
        printInOrder(r.left);
        System.out.println(r.data + " ");
        printInOrder(r.right);
        
    }
    
    public int min(){
        
        if(root == null) return Integer.MIN_VALUE;
        
        TNode p = root;
        
        while(p.left!=null)
            p = p.left;
            
        return p.data;  
        
        
    }
    
        public int max(){
        
        if(root == null) return Integer.MIN_VALUE;
        
        TNode p = root;
        
        while(p.right!=null)
            p = p.right;
            
        return p.data;  
        
        
    }
    
    public TNode search(int n){
        
        if(root == null) return null;
        
        
        TNode q = root;
            
            
            while(q!=null && q.data!=n){
                
                
                
                if(n < q.data)
                  q = q.left;  
  
                else
                 q = q.right;     
                
                
            }
        
            return q;
    }
    
    
}

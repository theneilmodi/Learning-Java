
public class SpecialCheckingAccount extends CheckingAccount
{
    
    private double minBal;
    private double annualInterest;

    public SpecialCheckingAccount(int idNumber, double startBal, double chkCharge, double minBal, double annualInterest){
        
        super(idNumber, startBal, chkCharge);
        this.minBal = minBal;
        this.annualInterest = annualInterest;
    }
    
    public void clearCheck(double amount){
        if(currentBalance() > this.minBal)
            decreaseBalance(amount);
        else
            super.clearCheck(amount);
    }
   
    public double monthlyInterest() {  
        
        if(currentBalance() > this.minBal){
            return (currentBalance()*this.annualInterest)/12;
        }else{
            return super.monthlyInterest();
        }
    }
}

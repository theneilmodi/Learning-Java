
/**
 * Write a description of class Account here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public abstract class Account
{
    private final int idNum;
    private double balance;
    
   public Account(int idNum, double balance){ 
       this.idNum = idNum;
       if(balance >= 0.0)
            this.balance = balance;
       else
        System.out.println("Money...");
    }
    
   public int idNumber(){
       return idNum;
    }
    
   public double currentBalance(){
       return balance;
    }
    
   public void deposit (double amount){
       if(amount >= 0.0){
           this.balance =+ amount;
        }
    }
    
   public void decreaseBalance (double amount){
        if(amount >= 0 && amount<=currentBalance()){
            this.balance =- amount;
        }
   }
   
   public abstract double monthlyInterest();
    
}

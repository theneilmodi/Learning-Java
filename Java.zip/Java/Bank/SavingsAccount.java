

public class SavingsAccount extends Account
{
    // instance variables - replace the example below with your own
    private double interestRate;
    
    public SavingsAccount(int idNum, int balance, int interestRate){
        
        super(idNum, balance);
        this.interestRate = interestRate;
    }
    
    public void decreaseBalance (double amount){
        if(amount >= 0 && amount<=currentBalance()){
            decreaseBalance(amount);
        }
   }
   
   public double monthlyInterest(){
       return (currentBalance() * interestRate)/12;
    }
}

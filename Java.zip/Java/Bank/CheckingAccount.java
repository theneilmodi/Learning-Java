

public class CheckingAccount extends Account
{
    // instance variables - replace the example below with your own
    private double checkCharge;
    public double interestRate;    
    
    public CheckingAccount(int idNumber, double startBal, double chkCharge)
        {
            super(idNumber, startBal); 
            checkCharge = chkCharge;
        }
    
     public void clearCheck(double amount) {
             decreaseBalance(amount + checkCharge); 
     }
     
     public double monthlyInterest() {  
       return (currentBalance() * interestRate)/12; 
     }
}

public abstract class Shape implements Toolkit
{
  String name;
  
  public Shape(String n)
  {
    name = n;
  }
  
  public void display()
  {  System.out.println(name);
  }
  
  public abstract double getArea();
  
}

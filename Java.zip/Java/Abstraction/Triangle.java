import java.util.*;

public class Triangle extends Shape
{
   
   private static List<Triangle> list = new ArrayList<Triangle>();
   
   double a, b, c;
   private static int ctr = 0;
   
   public Triangle(int x, int y, int z)
   {
     super("Illegal Triangle");
     if(x+y> z && y+z>x && x+z>y)
     {  name = "Triangle" + ++ctr;
        a = x; b = y; c = z; 
    
    } 
     
    list.add(this);
   }
   
   public static void printAll(){
       
       for(Triangle element : list)
        element.display();
    }
   
   public void display()
   { super.display();
     System.out.println("Side1 = " + a + " Side2 = " + b + " Side3 = " + c );
   } 
   
   public double getArea()
   {
     if(name.equals("Illegal Triangle"))
       return 0.0;
     else { double s = (a+b+c)/2.0;
            return Math.sqrt(s*(s-a)*(s-b)*(s-c));
          }
   }
   
   public double twiceArea()
   {
      return 2*getArea();
   }
}


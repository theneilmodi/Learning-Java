// email address = dhhyey@gmail.com


public class Canvas
{
   public static void displayAll(Shape[] sr)
   {
     // Shape[] sr = {new Triangle(3,4,5), new Rectangle(4,5), new Triangle(2,4,7), new Rectangle(3,7), new Triangle(4,4,4)};
      for(int i = 0; i < sr.length; i++)
      { sr[i].display();
        System.out.println("Area = " + sr[i].getArea());
        System.out.println("---------------");
      }
   }
   
   public static void main(){
       
       Shape s = new Triangle(3,4,5);
       Shape s2 = new Triangle(4,5,7);
       
       Triangle.printAll();
    }
   

}

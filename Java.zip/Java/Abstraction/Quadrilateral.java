public abstract class Quadrilateral extends Shape
{
  double a, b, c, d;
  
  public Quadrilateral(int p, int q, int r, int s, String n)
  {
    super(n);
    a = p; b = q; c = r; d = s;
    
  }

}


public class Rectangle extends Quadrilateral
{
  private static int ctr = 0;
  
  public Rectangle(int p, int q)
  {
     super(p,q,p,q,"Rectangle"+ ++ctr);
  }
  
  public double getArea()
  {
     return a*b;
  }
  
  public double twiceArea()
  {
      return 2*getArea();
  }   
}

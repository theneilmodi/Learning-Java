public interface Toolkit
{
   public double twiceArea();
   
}

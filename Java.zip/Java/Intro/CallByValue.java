

public class CallByValue
{
    public static void main(){
        
        int a = 6;
        change(a);
        System.out.println(a); // 6 NOT 7
        
        a = change(a);
        System.out.println(a); // This time the output will be 7
        
        int[] br = {9,10,11};
        change(br);
        System.out.println(br[0]); // 14
    }
    
    public static int change(int a){  // call by value
       
        System.out.println(a); //6
        a = a+1;
        System.out.println(a); //7
        return a;
    }
    
    public static void change(int[] z){ // call by ref
       
        System.out.println(z[0]); //9
        z[0] = z[0]+5;
        System.out.println(z[0]); // 14
        
    }
}

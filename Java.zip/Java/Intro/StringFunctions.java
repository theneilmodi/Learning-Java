

public class StringFunctions
{
    // instance variables - replace the example below with your own
   public static void main(){
       
       String s = "Hello World";
       
       System.out.println(s.length());
       System.out.println(s.charAt(6));
       System.out.println(s.indexOf('o'));
       System.out.println(s.lastIndexOf('o'));
       
       System.out.println(s.indexOf('o',5)); 
       System.out.println(s.indexOf('z',5));  // not found = -1
       System.out.println(s.indexOf("or")); //7
       
       System.out.println("BAT".equals("bat")); //false
       System.out.println("BAT".equalsIgnoreCase("bat")); // true
       
       if(response.equalsIgnoreCase("yes"))
            System.out.println("YESSS!!!");
       
       
       System.out.println("batman".compareTo("zorro"));  // negative number   
       System.out.println(".zorro".compareToIgnoreCase("Zorro"));     
       
       // add and subtracting 32 to change case
    }
}

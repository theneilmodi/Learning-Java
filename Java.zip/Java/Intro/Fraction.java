
public class Fraction
{
    int num;
    int den;

    public Fraction(){
       
        num = 0;
        den = 1;
        
    }
    
    public Fraction(int k, int j){
        
        if(j!=0){
            num=k;
            den=j;
            reduce();
        }else{
            num = 0; 
            den = 1;
        }
    }
    
    public void display(){
        
            System.out.println(num + "/" + den);
       
            
    }
    
    private void reduce(){
        for(int i = num; i>0; i--)
            if(num%i == 0 && den%i == 0)
                {
                num = num/i;
                den = den/i;}
              
        
    }
    
    public double value(){
        
        double get_value = (double)num/den;
        return get_value;
    }
 
    public Fraction multiply(Fraction z){
        
       Fraction created = new Fraction(num * z.num,den * z.den);
       return created; 
    }
    
    public void add(int val){
        
        Fraction f = new Fraction(val,1);
        add(f);
        
    }
    
     public void add(Fraction z){
        
        num = z.num * den + num * z.den;
        den = z.den * den;
        reduce();
        
   
    }
    

}


public class Circle
{
   
    double radius;
    Point center;
    
    public Circle(){
        
        radius = 1;
        center = new Point(); // origin
    }
    
    public Circle(double rad, double x, double y){
        
        center = new Point(x,y);
        radius = rad;
        
    }
    
    public Circle(double rad, Point p){
        
        radius = rad;
        center = new Point(p.x, p.y);
        
        //center = p; Not a good idea because if the external point changes in the 
        //future then the circle changes. If we dont want this to happen
        // we need to create a new point with x and y values of p
        
    }
    
    public boolean contains(Point p){ // returns true if P is inside circle
        
        if(center.distanceTo(p) < radius)
            return true;
        else 
            return false;
    }
    
    public boolean touches(Circle B){
        
        if(this.radius + B.radius == this.center.distanceTo(B.center))
            return true;
        else
            return false;
   
    }
    
    public boolean intersects(Circle B){
        
        if(this.radius + B.radius > this.center.distanceTo(B.center))
            return true;
        else 
            return false;
            
    }
    
    
}

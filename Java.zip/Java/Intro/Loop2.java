
public class Loop2
{
    // instance variables - replace the example below with your own
    public static void main(int number, int limit){
        
        for(int i = 0; i<=limit; i++){
            
            System.out.println(number + " * " + i + " = " + (number*i));
            
        }
        
        
    }
}


public class StringPrograms
{
    
    public static void main(String s){
        
       /*for(int k = 0; k< s.length(); k++){
           
           char ch = s.charAt(k);
           System.out.println(ch);
           
        }*/
      
        int pal = 0;
    
        for(int k = 0; k< s.length(); k++){
           
           char ch = s.charAt(k);
           char ch2 = s.charAt((s.length()-1)-k);
           
           if(ch == ch2)
            pal++;
          
        }
        
        if(pal == s.length()) 
            System.out.println("Palindrome");
        else
            System.out.println("Not A Palindrome"); 
    }
  
    
    public static void HW2(String s){
        
        String k_new1 = "";
        String k_new2 = "";
        int first_length = 0;
        
        for(int k = 0; k< s.length(); k++){
           
           char ch = s.charAt(k);
           
           if(ch == ' '){ 
               
               if(k == first_length)
               k_new2 = k_new1;
               
               
               
               if(k_new2.length() >= k_new1.length())
               k_new1 = " ";
               
               if(k_new1.length() > k_new2.length())
               k_new2 = " ";
              
            }else{
                
                k_new1 = k_new1 + ch;
                first_length++;
            }
           
        }
        
        if(k_new2.length() > k_new1.length())
             System.out.println(k_new2);
               
        if(k_new1.length() > k_new2.length())
             System.out.println(k_new1);
             
      
        
    }
}

/*
 * HW 3
 * 
 * "rain in spain falls slowly"
 * 
 * order of words opp
 * 
 * 
 * HW 2
 * 
 * print the longest word(s) in a sentence
 * 
 * HW 1
 * 
 * Count the number of consonanats
 * 
 * HW 0
 * 
 * Print each word on a new line
 */

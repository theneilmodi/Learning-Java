
/**
 * Write a description of class Loop1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Loop1
{
    // instance variables - replace the example below with your own
    public static void main(){
        /*
        for(int i = 100; i>=1; i--){
            
            if(i%5 == 0 && i%4 == 0)
                System.out.println(i);
               
        }
        
        */
       double counter_add = 1.0;
       double add_prob = 9.0;
       
       double answer = Math.round((counter_add*100)/add_prob);
       
       System.out.println(answer);
       
    }
}

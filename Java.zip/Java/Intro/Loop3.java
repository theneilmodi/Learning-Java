
/**
 * Write a description of class Loop3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Loop3
{
    // instance variables - replace the example below with your own
    public static void main(int num){
        
        
        
        
        for(int i=1;i<=num; i++){
           
            System.out.println(i + " " + ((num+1)-i));
         
        }
        
        
    }
}

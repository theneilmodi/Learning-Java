
public class LongestWord
{
    // instance variables - replace the example below with your own
  public static void func(String s)
  {
    s = s.trim();
    String word = "", longestWord = ""; 
                                     // i =  0 1 2 3 4 5 6 7 8 9 10
    for(int i = 0; i < s.length(); i++)   // H E L L O   W O R L D
    {
      char ch = s.charAt(i);
      if(ch != ' ')
         word = word + ch;
      else {  // word is ready
         if(word.length() > longestWord.length())
             longestWord = word;
         word = "";
      }
    }// end of loop 
    
    if(word.length() > longestWord.length())
       longestWord = word;    
    
    
    System.out.println("The longest word is " + longestWord);
 }


 public static void func2(String s) // rain in spain ---> spain in rain
  {
    s = s + " ";
    String word = "";
    String sentence = "";
    
    for(int i = 0; i < s.length(); i++)
    {
      char ch = s.charAt(i);
      if( ch != ' ')  
         word = word + ch;      //  spain
      else {
         sentence = " " + word + sentence;
          word = "";
       }
    }
    System.out.println(sentence);
  }

}


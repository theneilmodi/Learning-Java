
public class ArrayPrograms
{
    public static void right(int[]ar){
                                          //   3
        for(int i = ar.length-1; i>=0; i--){ // {2  5  7  9  8  3}
          
          if(i == 0)
            break;
          else if(i == ar.length-1)
            ar[0] = ar[ar.length-1];
          else 
            ar[i+1] = ar[i];
           
        }
      
        for(int i = 0; i<ar.length; i++){
            
            System.out.println(ar[i]);
            
        }
    }
    
    public static void reverse(int[]ar){ // {1  2  3  4  5  6}
        
    int c = 0;
    
        for(int i = 0; i<ar.length/2; i++){
            
            int m = (ar.length-1)-i;
            c = ar[m];
            ar[m] = ar[i];
            ar[i] = c;
            
        }
        
        for(int i = 0; i<ar.length; i++){
            
            System.out.println(ar[i]);
            
        }
        
    }
    
    public static void bubble(int[]ar){ //{1,7,2,4,8,1,3}
    
    int k = 0;
    boolean sorted = true;
    for(int m = 0; m<ar.length-1; m++){
        sorted = true;
        for(int i = 0; i<ar.length-1-m; i++)
            if(ar[i]>ar[i+1]){
               sorted = false;
               k = ar[i+1];
               ar[i+1] = ar[i];
               ar[i] = k;               
                  
             }
        if(sorted) break;
    }
    
    for(int f = 0; f<ar.length; f++){
            
            System.out.println(ar[f]);
            
     }
  }
  
  
  public static void main(){
      
      int[] s = {2,5,13,18,19,41};
      int[] d = {3,6,8,17};
      
      int[] e = mergeSortedArrays(s,d);
      
          for(int f = 0; f<e.length; f++){
            
            System.out.println(e[f]);
            
     }
  }
  
  
  
  public static int[] mergeSortedArrays(int[]a, int[]b){
      
     // a and b are sorted arrays
     // create and return array c in which data from a and b is merged in such
     // a way that c is sorted
     /*
     a) 2 5 13 18 19 41
     b) 3 6 8  17
     
     c) 2 3 5 6 8 13 17 18 19 41
     */
    
     int[] c = new int[a.length + b.length];
     int a_marker = 0;
     int b_marker = 0;
     int c_marker = 0;
     
     while(a_marker < a.length && b_marker < b.length){
         
         if(a[a_marker] < b[b_marker])
                c[c_marker++] = a[a_marker++];
         else
                c[c_marker++] = b[b_marker++];
                
                 
     }
      
     while(a_marker < a.length)
             c[c_marker++] = a[a_marker++];
             
     while(b_marker < b.length)
             c[c_marker++] = b[b_marker++];       
         
        
     return c;
     
    }
}

/*
 * Functions
 * Recurssions
 * Multi Dimensional 
 * Bin Search
 * Quick Sort
 */
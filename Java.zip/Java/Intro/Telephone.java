
/**
 * Write a description of class Telephone here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Telephone
{
    // instance variables - replace the example below with your own
    public static void main(int m){
        
       
        /*m = minutes consumed
         * 200 - rental
         * 
         * m <= 100       FREE
         * 101 - 300      1.5/minute
         * 301 - 700      1.2/minute
         * m > 700        1.1/minute
         * 
         * Example 750 minutes
         * 
         * 200 + (200*1.5) + (400*1.2) + (50*1.1)
         */ 
         double new_m = 0;
        
            new_m = new_m + 200;
            
        if(m>=101 && m<=300)
            new_m = new_m + ((m-100)*1.5);
           
        if(m>=301 && m<=700)    
            new_m = new_m + ((m-300)*1.2);
        
        if(m>700)
            new_m = new_m + ((m-700)*1.1);
            
        System.out.println("You have to pay" + new_m);
        
        
        
    }
}


public class MoreStringHw
{
    // instance variables - replace the example below with your own
    public static void namefunc(String s){ 
        
        s = s.trim();
        s = " " + s;  
        String sentence = "";
        String lastWord = "";
        boolean checker = true;
        
        for(int k = s.length()-1; k>=0; k--){
           
           char ch = s.charAt(k);
           
           if(ch == ' '){
            
               if(checker == false){
               sentence = s.charAt(k+1) + ". " + sentence; 
              }
             
              checker = false;
              
           }else{
               
               if(checker == true)
               lastWord = ch + lastWord;
               
            }
           
        }
        
        System.out.println(sentence + lastWord);
        
    }
    
    public static void letter(String s){
        
        s = s.trim(); //" There is a boy "
        s = " " + s + " ";
        String back_sentence = "";
        String forw_sentence = "";
        boolean space_checker = false;
        
        for(int k = 0; k<s.length(); k++){
           
            char ch = s.charAt(k);
            
           if((ch == 'e' || ch == 'E') && space_checker == true){ // Charlesa is friendly
               
               for(int back = k; ;back--){
                   
                   char back_ch = s.charAt(back);
                   if(back_ch == ' '){
                       break;
                    }else{
                       back_sentence = back_ch + back_sentence; 
                    }
                }
                
               for(int forw = k+1; ; forw++) {
                   
                   char forw_ch = s.charAt(forw);
                   
                    if(forw_ch == ' '){
                       break;
                    }else{
                       forw_sentence = forw_sentence + forw_ch; 
                    }
                   
                }
              
                System.out.print(back_sentence + forw_sentence + " ");
                back_sentence = "";
                forw_sentence = "";
                space_checker = false;
                
            }else if(ch == ' '){
                space_checker = true;
            }
        }
        
        
    }
    
    public static void main(String s){
        
        s = s.trim();
        s = s + " ";
        String word = "";
        
        boolean flag = false;
        
         for(int k = 0; k<s.length(); k++){
             
             char ch = s.charAt(k);
             
             if(ch != ' '){
                if(ch == 'e')
                    flag = true;
                    
                    word = word + ch;
            }else{
                 // IF SPACE
                 /*if(word.indexOf('e') != -1)
                    System.out.println(word);*/
                    if(flag == true)
                        System.out.print(word + " ");   
                 word = "";
                 flag = false;
                }
         }
        
        
    }
    
    public static void replace(String s, String oldWord, String newWord){
        
        s = s.trim();
        s = s + " ";
        String word = "";
        
        for(int k = 0; k<s.length(); k++){ // london calling this year
            
            char ch = s.charAt(k);
            
            if(ch == ' '){
                
                if(word.equalsIgnoreCase(oldWord)){
                System.out.print(newWord + " ");
                }else{
                System.out.print(word + " ");    
                }
                
                word = "";
            }else{
                
               word = word + ch; 
            }
        }
        
    }
}

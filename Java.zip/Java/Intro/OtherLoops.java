
public class OtherLoops
{
    // instance variables - replace the example below with your own
    public static void main(){
        
        int j = 1;
        
        while(j<=5){
          
            System.out.println(j);
            j++;
        }
        
        int k = 1;
        
        do{
            System.out.println(k);
            k++;
        }while(k<=5);
    }
}

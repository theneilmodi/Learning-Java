

public class QuickSort
{
    public static void main(){
        
        int[] ar = {4,8,9,1,0,2,4,3,1,2,7,8,6,1};
        
        quickSort(ar, 0, ar.length-1);
        
       for(int i = 0; i<ar.length; i++) 
            System.out.print(ar[i] + " ");
    }


    public static void quickSort(int[] a, int begin, int end){
        
      if(begin >= end) return;
      
       
      /* we will partition the array between begin and end
       * 1. Pick up the element at end (pivot) and place it in its final place
       * 2. All elements to the left of pivot should be less than pivot
       * 3. All elements to the right of pivot should be greater than or eqaul to pivot
       * 4. Returns index of pivot
       */
       
      int pivot = partition(a,begin,end);
      
      quickSort(a,begin,pivot-1);
      quickSort(a,pivot+1,end);
      
       
    }
    
    public static int partition(int[] a, int begin, int end){
        
        int ctr = 0;
        
        for(int i = begin; i<=end; i++){
            
          if(a[i] <= a[end]){
              
              int temp = a[begin+ctr];
              a[begin+ctr] = a[i];
              a[i] = temp;
              ctr++;
              
            }
        }
       
 
        
        return begin+ctr-1;
    }
    
  
}

// Quick Sort and Data Structures

public class Coin
{
    // instance variables - replace the example below with your own
    public static void main(){
        
        // 1 is head
        // 2 is tail
        int sum = 0;
        
       int n = 3000;
        
        for(int i = 0; i<=10; i++){
        
        int counter = 0;
        int heads = 0;
        
            while(heads < 2 ){
            
                counter++;
            
                int toss = (int)(Math.random()*2)+1;
            
                    if(toss == 1) heads++;
                    else heads = 0;
                 
            }
        
        sum = sum + counter;
       }
       
       System.out.println("Coin was tossed three thousand times. The average for 3 heads in a row is " + (sum/3000) );
       
       
       
    
    
    
    }
    
    public static void five(int times){
        
        
        
        int total_heads = 0;
        int total_tails = 0;
        
         for(int i = 0; i<=times; i++) {   
             
         int counter = 0;
         int heads = 0;
         int tails = 0;
         
         
         
         while(counter < 5){
             
         int toss = (int)(Math.random()*2)+1;
         
            if(toss == 1) { heads++; total_heads++;}
            else {tails++; total_tails++;}
           
         counter++;   
         }// while
         
         System.out.println("Heads = " + heads + "\nTails = " + tails + "\n\n");
         
         }//for
        
        System.out.println("\n\n Probability of Heads = " + ((double)total_heads/times) + "\n Probability of Tails = " + ((double)total_tails/times));
         
    }
}
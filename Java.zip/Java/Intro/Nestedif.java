
public class Nestedif
{
    // instance variables - replace the example below with your own
   public static void main(){
       
       if(1==0){
       
       if(0==0)
           System.out.println("Statement 1");
           
        }
       else
            System.out.println("Statement 2");
       
        System.out.println("End");  
           
           
           
       
       
    }
}

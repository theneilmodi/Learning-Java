
public class Nextday
{
   public static void main(int day, int month, int year){
       
   boolean leap_checker = false;
   int dMonth = 0;
 
       
       System.out.println("Today is " + day + "/" + month + "/" + year);
   
   // Checking if leap year or not
       
   if(year % 100 == 0 && year % 400 == 0 || year % 100 != 0 && year % 4 == 0)
    leap_checker = true;
    
       
    // Finding out how many days in the month
       
    if(month == 1 || month == 3 || month == 5 || month == 7 || month == 8 || month == 10 || month == 12)
        dMonth = 31; 
    else if(month == 4 || month == 6 || month == 9 || month == 11)
        dMonth = 30;
    else if(month == 2 && leap_checker == false)   
        dMonth = 28; // Not a leap year
    else if(month == 2 && leap_checker == true)
        dMonth = 29; // leap year
    
     
        

   
   //Increasing day
   if(day == dMonth)
        day = 1;
   else
        day++;
       
  
   if(day == 1 && month == 12){ // Year and month change, annual change
        month = 1;
        year++;
    }else if(day == 1)
        month++;  // month increases, regular month change
   
   
   
   
   // Final Output
   System.out.println("Tomorrow is " + day + "/" + month + "/" + year);
        
       
    }

}

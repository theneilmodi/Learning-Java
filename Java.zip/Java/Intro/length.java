
public class length
{
    // instance variables - replace the example below with your own
    
    public static void main(){
    String s = "hello";
    
    System.out.println(s.length());
    
    }
}

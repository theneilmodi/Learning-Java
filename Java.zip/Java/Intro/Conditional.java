
public class Conditional
{
    public static void Quadri(int s1, int s2, int s3, int s4, int d1, int d2){
       
        if(s1 == s2 && s2 == s3 && s3 == s4 && d1 == d2){
            
            System.out.println("Square");
            
        }else if(s1 == s2 && s2 == s3 && s3 == s4 && d1 != d2){
            
              System.out.println("Rhombus"); 
                     
        }else if(s1 == s3 && s2 == s4 && d1 == d2){
            
              System.out.println("Rectangle"); 
                     
        }else if(s1 == s2 && s3 == s4 && d1 != d2){
            
              System.out.println("Kite"); 
                     
        }else if(s1 == s3 && s2 == s4 && d1 != d2){
            
              System.out.println("Parallelogram"); 
                     
        }else{
            
            System.out.println("Quadrilateral"); 
            
        }
        
       
    } 
    
    
    public static void triangle(int a, int b, int c){
        
        if(a > b && a > c) { // a is greaatest
            
            int right = b*b + c*c;
            
                if((a*a) == right){
                    
                 System.out.println("Right Angled Triangle with " + a + " as hypotenuse");   
                    
                }
            }
        else if(b > c && b > a) {// b is greaatest
            
            int right = a*a + c*c;
            
                if((b*b) == right){
                    
                 System.out.println("Right Angled Triangle with " + b + " as hypotenuse");   
                    
                }
            }
         else if(c > b && c > a) {// c is greaatest
            
            int right = a*a + b*b;
            
                if((c*c) == right){
                    
                 System.out.println("Right Angled Triangle with " + c + " as hypotenuse");   
                    
                }
            } else{  

              if(a != b && b != c){
          
                       System.out.println("Scalene");
            
               }else if(a == b && b == c){
            
                        System.out.println("Equilateral");
             
                }else if(a==b || b==c || c==a) {
                    
                    
                        System.out.println("Isoceles");
        
                }
        
    }
    
    
    
    
}




public class Ascii_table
{
   
    public static void main(){
    for(int i = 1; i<=128; i++){
        
        if(i != 12){
            
            
        
        System.out.print(i + " = " + (char)i + "   ");
        
        if(i%6 == 0)
            System.out.println("");
            
        }
    }
    
    
    
}
}


public class BankAccount
{
    
    String name;
    double balance;
   String acnum;
   static double rate = 0.08;
   
   private static int count = 0;
    
    public BankAccount(String n){ // Parameter constructor
        
        name = n;
  
        this.acnum = "" + ++count;
    }
    
    public void deposit(double amt){
     
        balance = balance+amt;
        System.out.println("Deposited Rs " + amt + " in " + name + "'s account");
    }
    
    public void display(){
        
        System.out.println(acnum + " Rs. " + balance + " - " + name + " Rate = " + rate);
    }
    
    public void withdraw(double amt){
        
        if(amt > balance) System.out.println("ERROR. Take out less");
        else {
            balance = balance-amt;
            System.out.println("Sucess!");
        }
    }
}

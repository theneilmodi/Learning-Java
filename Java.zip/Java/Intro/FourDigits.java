
/**
 * Write a description of class FourDigits here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FourDigits
{
    // instance variables - replace the example below with your own
   public static void main(int num){
       
       int p4 = num%10;
       int p3 = (num/10)%10;
       int p2 = (num/100)%10;
       int p1 = (num/1000)%10;
       
       System.out.println(p1 + " + " + p2 + " + " + p3 + " + " + p4 + " = " + (p1+p2+p3+p4));
       
       
    }
}

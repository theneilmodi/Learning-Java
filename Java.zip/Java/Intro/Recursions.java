//  01234
//  HELLO

public class Recursions
{
    public static void func(String s){
    
        if(s.length() == 0)
            return;
            
    System.out.print("-");    
    func(s.substring(1));
    System.out.print(s.charAt(0)); 
    
    }
    
    public static void HW1(String s){ // abcde = aebdc
        
        if(s.length() == 0)
            return;
        else if(s.length() == 1)
            System.out.print(s);
        else{
            System.out.print(s.charAt(0) + "" + s.charAt(s.length()-1));
            HW1(s.substring(1, s.length()-1));
        }
        
    }

    public static int calculator(String s){
        
    if(s.length()==0)
        return 0;
    else if(s.length() == 1)
        return (s.charAt(0) - '0');
    else{
        
      int num = s.charAt(0) - '0';
      
      if(s.charAt(1) == '+')
        return num + calculator(s.substring(2));
      else
        return num - calculator(s.substring(2));
    }
    
        
    }
    
    public static void array(int[]a, int begin ){

        
    }
    
    public static int factorial(int num, int total){
      
        if(num == 0){ 
            System.out.println(total);
            return total;
        }else {
          total = total * num;
          return factorial(num-1, total);
          
        }
    }
}

/* hw: if input is "abcde" ---> aebdc
 *                  "abs" ---> asb
 *   : if input is "abcde" --->
 * 
 * hw 2 : if input is an array  ----> output the max
 *      : int[] a, int[begin]
 *      
 * hw 3 : input is "2+3-7" only plus an    
 */
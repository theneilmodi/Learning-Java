class Example                         
{                              
   public static void func()
   {  
    System.out.println("Hello World");
    System.out.println(2 + 3);   //  5
    System.out.println("2 + 3"); // 2 + 3
    System.out.println( 8 / 3 ); // 2 because in java int and int always give an int
    System.out.println( 8.0 / 3 ); // 2.6666
    System.out.println( 20 / 100); // 0
    System.out.println( 20 / 100 * 400); // 0
    System.out.println( 20f / 100 * 400); // 80.0
    /*              B
     * 
     *              D M Mod
     *              A S
     */     
    System.out.println( 24   /8*3  ); // 9
    /*             24
     *           -------
     *            8 X 3
     */
    System.out.println( 24/(8*3)  ); // 1
    /*             8 x 3
     *           -------
     *              24
     */
    System.out.println( 8 * 3 / 24); // 1
    System.out.println("hello " + "once again!"); // hello once again!
    System.out.println("The answer is " + 2*3); 
    System.out.println("The answer is " + 2+3); //The answer is 23
    System.out.println("The answer is " + (2+3)); //The answer is 5
    System.out.println(2+3+" is the answer."); // 5 is the answer
    System.out.println("The answer is " + (5 - 2)); // The answer is 3
    
    System.out.println("10 % 4 is " + 10%4); // 2
    System.out.println("21 % 7 is " + 21%7); // 0
    System.out.println("15 % 4 is " + 15%4); // 3
    
    // types of variables
    
    int amount;
    amount = 8;
    System.out.println(amount);
    // 8 = amount; this is illegal because LHS must always be a variable
    
    amount = 10;
    System.out.println(amount);
    
    double fract = 12.0/5;
    
    System.out.println(fract); // 2.4
    
    System.out.println(amount + fract);
    
    System.out.println(20/100*400.0); // 0.0
    System.out.println(20*400.0/100); // 80.0
    //Lesson: 20 percent is best writen as 0.2 instead of 20/100
    
    String sent = "This is a string";
    
    char ch = 'a';
    
    System.out.println(ch + 0 ); // 97
    System.out.println("" + ch + 0); // a0
    
    System.out.println(8/0.0); // infinity
    //System.out.println(8/0); // error
    
    char first_letter = 'A';
    System.out.println("First letter is " + first_letter); //first letter is A
    
    System.out.println(ch + first_letter); // 162
    
    /* when two characters are added,
     then the sum of their numeric value is displayed
    */
    
    byte b = 127; // 1 byte (-128 to 127 only)
                   // bit is a binary digit
                   // byte is 8 bits
                  
    short sh = 32767; // 2 bytes (-32768 to 32767)
    
    int n = 27; // 4 bytes
    
    long lon = 76;  // 8 bytes
    
    
    float fl = 2.6f; // 8 places (4 bytes)
    
    double dd = 2.2387429384729; // 16 places (8 bytes)
    
    boolean bool = true;
    
    // && is higer precedence than ||
    
   System.out.println(!(5<8)); // ! not same as !=
    
   int x = 4;
   //x is 4
   x -= x-- - --x;
   
   /*
    * Step 1 : Get rid of of -=
    * x = x - (x-- - --x)
    * 
    * Step 2 : Substitute the values of variables from L to R ignoring bodmas
    * x = 4 - (4 - 2)
    * x = 4 - 2
    * x = 2
    */
   
    System.out.println(x);
   }

}


/**
 * Write a description of class Time here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Time
{
    // instance variables - replace the example below with your own
   /*
    * 24 hour format
    * 
    * h1, m1
    * h2,m2
    * 
    * 16:23 dep 
    * 8:15 arrive
    * 
    * 
    * 
    */
   
   public static void main(int h1, int m1, int h2, int m2){
       
       int new_h;
       int new_m;
       
       if(h1 >= h2 )
            new_h = h1-h2;
          else
            new_h = h2-h1;
         
           
        if(m1 >= m2)
              new_m = m1-m2;
            else
              new_m = m2-m1;  
        
        if(new_h != 0)      
            System.out.println("The journey took " + new_h + " hours and " + new_m + " minutes.");
           else
            System.out.println("The journey took " + new_m + " minutes.");
    }
    
}

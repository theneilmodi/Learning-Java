
public class Functions
{
  public static void main(String[] args)
  {
    System.out.println("Inside Main-Begin");
    product(5,8); 
    System.out.println("The end");
    System.out.println("Back in main after product");
    double value = maximum(15,8,2);
    System.out.println("Value is "+value);
    String s=explode("hello");
    System.out.println("s has become "+s);
    if( isPrime(11) )
       System.out.println("11 is a prime number");
    else System.out.println("11 is not prime");  
    System.out.println("And finally");
    threeStars();
    System.out.println("THE END");
    threeStars();
    System.out.println(maximum(100,200,150));

    }

    public static void product(int a,int b)
    { System.out.println("First line of product");
      System.out.println("The product of " + a + " and "+b+" is "+a*b);
      threeStars();
      System.out.println("Back in product");
      
    }

    public static double maximum(double a,double b,double c)
    {
        if(a>b && a>c)
            return a;
        else if(b>a && b > c)
            return b;
        else return c;
    }

    public static String explode(String s)
    {  
        // if s is hello
        // s should become h e l l o 
        
        return "output";

    }

    public static boolean isPrime(int n)
    {
        return false;

    }

    public static void threeStars()
    {
        System.out.println("***");
        
        if( 1 + 1 == 2 )
           return;
        
        System.out.println("Will not execute");
    }
    
    public static double root(int n)
    {
        // calculates the square root of n
        // returns the value
        return 8.0;
    }     

}

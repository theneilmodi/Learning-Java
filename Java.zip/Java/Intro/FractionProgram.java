
public class FractionProgram
{
   public static void main(String[] args){
       
       Fraction a = new Fraction();
       Fraction b = new Fraction(2,3);
    
       a.display(); //  0/1
       b.display(); //  2/3
       
       double result = a.value() + b.value(); 
       System.out.println(result); // 0.6666
       
       a.add(2);
       a.display(); // 2/1
       
       Fraction c = b.multiply(a);
       
       c.display(); // 4/3
       b.display();  // 2/3
       
       c.add(b);
       
       c.display(); //  2/1
       
    }
   
}

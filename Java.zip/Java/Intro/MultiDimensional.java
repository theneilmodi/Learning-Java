
public class MultiDimensional
{
    // instance variables - replace the example below with your own
    public static void analyze(int[][] ar){
        
        int max = 0;
        
        for(int i = 0; i<ar.length; i++){
            
            for(int j = 0; j<ar[i].length; j++)
                
                 if(max < ar[i][j])
                     max = ar[i][j];
                     

        System.out.println(max + "\n");  
         max = 0;
                 
         }       
    }
}


/* Accept two 2D arrays
 * 
 * public static int[][] join(int[][]a, int[][]b)
 * 
 * join two matrixes
 * 
 * return null if the rots of a anb are not the same
 */
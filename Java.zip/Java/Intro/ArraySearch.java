
public class ArraySearch
{
    public static void Linsearch(int ar[], int x){
      
      
      
      for(int i = 0; i<ar.length; i++){
          
          if(ar[i] == x){
             System.out.println(i); 
            }
          
        }
      
      
    }
    
    // ASSUMES THAT IT IS SORTED
    public static int binsearch(int a[], int n){
        
        int L = 0, U = a.length-1, M;
        
        while(L <= U){
            M = (L+U)/2;
            
            if(n<a[M])
                U = M-1;
            else if(n>a[M])
                L = M+1;
            else return M;
        }
        
        return -1;
    }
    
    public static int bin_recurs(int a[], int n, int begin, int end){
        
        
        
        if(begin > end)
            return -1;
        
        int m = (begin+end)/2;
        
        if(n < a[m])
            return bin_recurs(a, n, begin, m-1);
        else if(n > a[m])
            return bin_recurs(a, n, m+1, end);
        else
            return m;
            

    }
}

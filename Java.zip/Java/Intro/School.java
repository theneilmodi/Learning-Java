// Ask the user students are there, accept the names and marks of n students,
// into two 1 D arrays, String array - name, String marks - 
// For loop, names and marks into array
// Print score the highest and lowed
// Name, Marks, Report(Above avg or lower)
// Bubble sort all, interchange 2 marks, u interchange two names
// Rank them

import java.util.Scanner;

public class School
{ 
    public static void main(){ 
             
        Scanner in = new Scanner(System.in);

         System.out.print("How many students are there? ");
         int total = Integer.parseInt(in.nextLine());
         
         String[] name = new String[total];
         int[] marks = new int[total];
         int sum = 0;
         
         System.out.println((char)12);
         
        // ENTRING
         for(int i = 0; i<=total-1; i++){ 
         
            System.out.print("Enter Name Of Student " +(i+1)+ " : ");
            name[i] = in.nextLine();
            System.out.print("Enter Marks Of Student " +(i+1)+ " : ");
            marks[i] = Integer.parseInt(in.nextLine());
            sum = sum + marks[i];
            System.out.println((char)12);
            
        }
        
        double average = (double)sum/total;
        
        //Individaul Reports
        System.out.println("Indivdual Reports \n");
        
        for(int j = 0; j<=total-1; j++){
            
            System.out.println(name[j] + " - " + marks[j]);
            if(marks[j] >= average)
                System.out.println(name[j] + " Is Above Average\n" );
            else
                System.out.println(name[j] + " Is Below Average\n" );
        }
        
        System.out.println("\n\n");
        
        
        //PRINTING HIGHEST TO LOWEST
        
        bubble(marks, name);
        
        System.out.println("Highest To Lowest \n");
        
        for(int k = 0; k<total; k++){
            
            System.out.println(name[k] + " - " + marks[k]);
        }
        
        System.out.println("\n\n");
        

        // RNAKING THEM
        
        System.out.println("Rank 1 : " + name[0]);
        
        int rank = 1;
        for(int b = 1; b<marks.length; b++){
            
            if(marks[b] < marks[b-1])
                rank = b+1;
                
            System.out.println("Rank " + rank + " : " + name[b]);
        }
        
      /*System.out.println("\n" + name[total-1] + " got " + marks[total-1] + " which is the highest.");
        System.out.println("\n" + name[0] + " got " + marks[0] + " which is the lowest.");*/
    }
    
        public static void bubble(int[] ar, String[] name){ //{1,7,2,4,8,1,3}
    
    int k = 0;
    String store = "";
    boolean sorted = true;
    for(int m = 0; m<ar.length-1; m++){
        sorted = true;
        for(int i = 0; i<ar.length-1-m; i++)
            if(ar[i]<ar[i+1]){
               sorted = false;
               k = ar[i+1];
               ar[i+1] = ar[i];
               ar[i] = k; 
               
               store = name[i+1];
               name[i+1] = name[i];
               name[i] = store;
                  
             }
        if(sorted) return;
    }
    
    
  }
}



// Print all twin primes till limit
// example if limit is 50 , output = {3,5} {5,7} {11,13} {17,19} {41,43}

public class Functions2
{
    
    public static void main(int limit){
        
        for(int i = 1; i<=limit; i++){
            
            if(isPrime(i))
                System.out.print(i + " ");
        }
        
    }
    
    public static boolean isPrime(int n){
        
        for(int i = 2; i<=(Math.sqrt(n)); i++)   
            if(n%i == 0)
                return false;
            
        if(n!=1)
            return true;
        else
            return false;
    }
}

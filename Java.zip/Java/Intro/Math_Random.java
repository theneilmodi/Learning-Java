
/**
 * Write a description of class Random here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Math_Random
{
    // instance variables - replace the example below with your own
   public static void main(){
       
       System.out.println("The square root is " + Math.sqrt(25));
       System.out.println(Math.round(2.8));
       System.out.println(Math.floor(2.9));
       System.out.println(Math.ceil(2.3));
       System.out.println(Math.abs(-5));
       System.out.println(Math.max(2,5));
       System.out.println(Math.min(2,5));
       System.out.println(Math.max(2,Math.max(3,7)));
       
       
       
       //System.out.println(Math.random()); // 0 to 1
       
       double r =  Math.random(); // 0 and 1
       double s = r*6; // 0-5.999
       int t = (int)(s); // 0-5
       int u = t+1; // 1-6
       
       
       
       System.out.println("uyutfyutf"+(int)5.9);
       
       
       int ctr1 = 0, ctr2 = 0, ctr3 = 0, ctr4 = 0, ctr5 = 0, ctr6 = 0;
       
       for(int i = 1; i<=10000; i++){
           
          int dice1 = (int)(Math.random()*6)+1;
           
           
           
          
           
           switch((int)dice1){
               case 1 : ctr1++;
                        break;
                        
               case 2 : ctr2++;
                        break;
                        
               case 3 : ctr3++;
                        break;
                        
               case 4 : ctr4++;
                        break;
                        
               case 5 : ctr5++;
                        break;
                        
               case 6 : ctr6++;
                        break;
            }
           
        }
       
       System.out.println("One - " + ctr1/10000.0);
       System.out.println("Two - "+ctr2/10000.0);
       System.out.println("Three - "+ctr3/10000.0);
       System.out.println("Four - "+ctr4/10000.0);
       System.out.println("Five - "+ctr5/10000.0);
       System.out.println("Six - "+ctr6/10000.0);
    }
}

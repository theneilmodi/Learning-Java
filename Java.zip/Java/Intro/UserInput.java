
import java.util.Scanner;

public class UserInput
{

    public static void main(){

        Scanner in = new Scanner(System.in);

        System.out.print("What is your name? ");

        String name = in.nextLine();

        System.out.print(name + ", what's your age? ");

        int age = Integer.parseInt(in.nextLine()); // Double.parseDouble

        System.out.println("In the year " + (2112-age) + " you will be 100 years old");
    }


    /*
     * Rock =1 , paper = 2, scissors = 3
     * 
     * choose 1,2,3  ---- user types 1,2 or 3
     * 
     * clear
     * 
     * second person - choose 1,2,3  ---- user types 1,2 or 3
     * 
     * random and math functions
     */

    //  \n , \t , \'

    public static void rock(){

        Scanner in = new Scanner(System.in);


        System.out.println("Rock = 1 \f, Paper = 2, Scissors = 3 \n");

        System.out.print("Player 1 - Rock, Paper or Scissors...  ");

        int p1 = Integer.parseInt(in.nextLine());

        System.out.println((char)12);

        System.out.println("Rock = 1 , Paper = 2, Scissors = 3 \n");

        System.out.print("Player 2 - Rock, Paper or Scissors...  ");

        int p2 = Integer.parseInt(in.nextLine());

        System.out.println((char)12);


        if(p1 == p2)
            System.out.println("It's a tie");
        else if(p1 == 1 && p2 == 3 || p1 == 2 && p2 == 1 || p1 == 3 && p2 == 2)// PLAYER ONE WINS
            System.out.println("Player one wins");
        else
            System.out.println("Player two wins");

    }

}
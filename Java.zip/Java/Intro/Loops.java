
/**
 * Write a description of class Loops here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Loops
{
    public static void main(){
        
        System.out.println("Begin");
        
        int i;
        
        for(i = 1; i<=5; i++){
            
            System.out.println(i);
            
        }
        
        System.out.println(i);
    }
}
// 100 to 1 divisible 4 and 5

// accept a number from a user and print the tables of that number till limit
// 1*4 = 4

//accept num and if n is 9  and print forward and backwards side by side

/*Notes
         * 
         * for(int x = 2, y = 8; x<=y; x++,y--)
         *      System.out.println(x + " " + y);
         *  
         *  for(char ch = 'a'; ch<='z'; ch++)
         *      System.out.println(ch +" ");
         */
        
        
        


public class January
{
   public static void main(int year){
       
       leap_checker = false;
       
        if(year % 100 == 0 && year % 400 == 0 || year % 100 != 0 && year % 4 == 0)
    leap_checker = true;
       
    //Jan 1 2011 is sat, Jan 1 2012 is sunday,  Jan 1 2013 is tuesday, Jan 1 2014 is wed
       
    if(leap_checker == false){
        
        int control  = 1949; // tuesday
        
        int leaps = (year-control)/4
    }
   
       
       
    }

}

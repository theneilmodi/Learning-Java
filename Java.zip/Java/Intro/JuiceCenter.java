import java.util.Scanner;

public class JuiceCenter
{
   
   public static void main(){
       int bill = 0;
       int drinks = 0;
       
       
       for(int i = 1; i>=0; i++){
       
       System.out.println("Nilay's Juice Center \n");
       System.out.println("1. Mango ..... AED 10");
       System.out.println("2. Banana ..... AED 5");
       System.out.println("3. Cocktail ..... AED 20");
       System.out.println("4. Apple ..... AED 15");
       System.out.println("5. Quit, Show Bill \n");
       
       System.out.print("What will you drink? ");
       Scanner in = new Scanner(System.in);
       String juice = in.nextLine();
       
       
       
       if(juice.equalsIgnoreCase("Mango")){
        bill = bill + 10;
        drinks++;
        System.out.println((char)12);
       }else if(juice.equalsIgnoreCase("Banana")){
        bill = bill + 5;
        drinks++; 
        System.out.println((char)12);
       }else if(juice.equalsIgnoreCase("Cocktail")){
        bill = bill + 20;
        drinks++;   
        System.out.println((char)12);
       }else if(juice.equalsIgnoreCase("Apple")){
        bill = bill + 15;
        drinks++;
        System.out.println((char)12);
       }else if(juice.equalsIgnoreCase("Quit") && drinks >= 2){
        break; 
       }else if(juice.equalsIgnoreCase("Quit") && drinks < 2){
            System.out.println((char)12);
        System.out.println("Please buy more \n");
        
        }else{
             System.out.println((char)12);
         System.out.println("There is no drink like that. Please select again \n");
         
        }
       
     }  
     
     System.out.println((char)12);
     
     if(drinks >= 4){
       
         int new_bill = bill - Math.round((bill*20)/100);
         System.out.println("You have bought " + drinks + " juices, so you got a 20% discount.");  
         System.out.println("Your original bill was " + bill + " AED, but now it is only " + new_bill+ " AED \n");
         System.out.println("Thank you!");
         
        }else{
            System.out.println("You have bought " + drinks + " juices. Your bill is " + bill + " AED \n");
            System.out.println("Thank you!");
     
        }
     
    }
}

/*
 * String Function Program
 * 
 * Stones
 * 
 * accept stones > 21, accept 3 moves < 5,
 * name palyer 1 and 2
 * whoever picks last stone loses, (1,2,3)
 * 
 * hw
 * 
 */

/**
 * Write a description of class Typecast here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Typecast
{
   public static void main(){
       
       System.out.println(22/7); //3
       System.out.println(22/7.0); //3.14
       System.out.println((double)(22/7)); // 3.0
       System.out.println((double) 22/7); //3.14
       System.out.println((int)'a'); //97 ASCII
       System.out.println((int)'A'); //65 ASCII
    }
}

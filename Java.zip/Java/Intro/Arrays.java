
public class Arrays
{
    
    public static void main(){
        
  
        
    
    int[]even = new int[26]; // 25
    int i = 0;
    for(int k = 0; k<even.length; k++){
        
        i = i+2;
        even[k] = i;
        
    }
    
    }
    
    public static void max_min(int[]ar){
        
        int i = 0;
        int max = ar[i];
        int min = ar[i];
        
        
      for(i = 1; i<ar.length; i++){ //{2,5,4,3,8}
        
        
          if(max < ar[i])
            max = ar[i];
          
          if(min > ar[i])
            min = ar[i];
        }
        
        System.out.println("Max = " + max);
        System.out.println("Min = " + min);
    }
  /* what are ar and br
   * what is the difference between ar, br and ordinary integer variables
   * Searching through arrays
   * Sorting arrays
   * Typical array programs
   * Multi Dimensional Arrays
   * 
   * 
   */  
  
  public static void Linsearch(int ar[], int x){
      
      
      
      for(int i = 0; i<ar.length; i++){
          
          if(ar[i] == x){
             System.out.println(i); 
            }
          
        }
      
      
    }
    
  public static void arrayref(){
      
      int[] ar = {5,10,15,20};
      
      int[] br;
      
      br = ar;
      
      br[0] = 100;
      
      System.out.println(ar[0]);
      
      
    }
}




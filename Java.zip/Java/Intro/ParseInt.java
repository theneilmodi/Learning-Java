

public class ParseInt
{
    // instance variables - replace the example below with your own
    public static void main(String s){
      
        int number = 0;
        
        for(int i = 0; i<=s.length()-1; i++){ //4321
            
            char ch = s.charAt(i);
            
            int diff = ch - '0';
            
            diff = diff * (int)Math.pow(10,s.length()-1-i);
            
            number = number + diff;
        }
        
        System.out.println(number);
    }
}

// SQUARE ROOT FUNCTION
// Round function , double number, int d = decimal places
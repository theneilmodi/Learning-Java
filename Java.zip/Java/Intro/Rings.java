
public class Rings
{
   public static void game(int n, char source, char help, char destination){
       
    if(n == 0)
        return; 
    else{
      
        game(n-1, source, destination, help);
        System.out.println(source + " to " + destination);
        game(n-1, help, source, destination);
        
    }
  }
  
  // Prints the nth term of the fibonnaci series
  
  public static void fibo(byte n, byte a, byte b){
      
      if(n == 0)
        return;
      else 
        System.out.println(a);
        fibo((byte)(n-1), b, (byte)(a+b));
    }
}

// Multi Dimensional
// Faster Sort - Quick Sort
// 
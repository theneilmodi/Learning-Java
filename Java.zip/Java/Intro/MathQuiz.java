import java.util.Scanner;


public class MathQuiz
{
  
  public static void main(){
      
      Scanner in = new Scanner(System.in);
      
      System.out.println("MATH QUIZ \n");
      System.out.print("Enter Name : ");
      String name = in.nextLine();
      System.out.print((char)12);
      
      
          int random_1;
          int random_2;
          int answer;
          double counter_add = 0;
          double counter_sub = 0;
          double add_prob = 0;
          double sub_prob = 0;
      
      for(int i = 1; i>=0; i++){
      
          System.out.println("Press 0 at anypoint to quit. You have attempted " + (Math.round(add_prob+sub_prob)) + " questions (Addition = " + Math.round(add_prob) + ", Subtraction = " + Math.round(sub_prob) +") \n");
          
          int sign = (int)(Math.random()*2)+1;
         
          
            if(sign == 1){ // ADDITION
                
                random_1 = (int)(Math.random()*98)+1;
                random_2 = (int)(Math.random()*98)+1;
                answer = random_1 + random_2;
                System.out.print(random_1 + " + " + random_2 + " = ");
                
            }else{ //SUBTRACTION
                
                random_2 = (int)(Math.random()*97)+1; //1-98
                random_1 = (int)(Math.random()*(98-random_2))+(random_2+1); // random 2 to 99
                answer = random_1 - random_2;
                System.out.print(random_1 + " - " + random_2 + " = ");
            }
          
            int user_ans = Integer.parseInt(in.nextLine());
            
                if(user_ans == 0 ){
                    
                    // REPORT
                    if(Math.round((counter_add*100)/add_prob) >= 75  && Math.round((counter_sub*100)/sub_prob) >= 75 && add_prob >= 5 && sub_prob >=5){
                    
                   break;
                    
                   }else{
                        System.out.print((char)12);
                        System.out.println("You are too dumb to quit. Keep trying! \n");
                   
                    }
                    
                }else if(user_ans == answer && sign == 1){
                    counter_add++;
                    add_prob++;
                    System.out.print((char)12);
                 
                }else if(user_ans == answer && sign == 2){
                    counter_sub++;
                    sub_prob++;
                    System.out.print((char)12);
                    
                }else{
                    
                    if(sign == 1)
                        add_prob++;
                    else
                        sub_prob++;
                    
                  System.out.print((char)12);    
                }
                 
      
        }
        
        System.out.print((char)12);
        System.out.println(name + ", you got " + Math.round(counter_add + counter_sub) + " correct out of " + Math.round(add_prob+sub_prob));
        System.out.println("\n Addition - " + Math.round(counter_add) + " / " + Math.round(add_prob) + " (" + Math.round((counter_add*100)/add_prob) + "%)" );
         
           
       if(Math.round((counter_add*100)/add_prob) >= 90)
            System.out.println("You are very good at Addition!");
      
       System.out.println("\n  Subtraction - " + Math.round(counter_sub) + " / " + Math.round(sub_prob) + " (" + Math.round((counter_sub*100)/sub_prob) + "%)" );
        
      if(Math.round((counter_sub*100)/sub_prob) >= 90)
            System.out.println("You are very good at Subtraction!");
    }
}

//
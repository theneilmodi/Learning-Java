public class Bnode
{
   BankAccount data;
   Bnode next;

   public Bnode(BankAccount ba, Bnode n)
   {
     data = ba;
     next = n;
   } 
}

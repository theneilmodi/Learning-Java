

public class BankProgram
{
    // instance variables - replace the example below with your own
    public static void main(String[] args){
        
        
        BankAccount b1; // b1 is a sticker, no object is created, b1 is a sticker
        
        //b1  = new BankAccount(); // Not working because default constructor is missing
       
        //System.out.println(b1.name); // defualt value
        
        //b1.name = "Nilay"; 
        //b1.balance = 4000;
        
        BankAccount b2 = new BankAccount("Dhyyey");
        
        b1  = new BankAccount("Amit");
        
        //b2.display();
        b2.deposit(5000);
        b1.deposit(1000);
        BankAccount.displayAll();
        //b2.display();
        
        //b2.name = "Dhhyey";
       // b2.balance = 1;
        
       
       
        // JUST STICKERS like arrays
         /*
        BankAccount b3 = new BankAccount();
        b3 = b1;
        b3.name = "Hijack";
        */
        //System.out.println(b1.name);
        
        // COPY is done individually
    }
}


public class BankAccount
{   private static Bnode head = null;
    private static double reserves = 0.0;
    String name;
    double balance = 0.0;
   String acnum;
   static double rate = 0.08;
   
   private static int count = 0;
    
    public BankAccount(String n){ // Parameter constructor
        name = n;
        this.acnum = "" + ++count;  
        head = new Bnode(this, head);
    }
    
    public void deposit(double amt){
        reserves = reserves + amt;
        balance = balance+amt;
        System.out.println("Deposited Rs " + amt + " in " + name + "'s account");
    }
    
    public void display(){
        
        System.out.println(acnum + " Rs. " + balance + " - " + name + " Rate = " + rate);
    }
    
    public void withdraw(double amt){
        
        if(amt > balance) System.out.println("ERROR. Take out less");
        else {
            reserves = reserves - amt;
            balance = balance-amt;
            System.out.println("Sucess!");
        }
    }
    
    public static void displayAll()
    {
      for(Bnode p = head; p != null; p = p.next)
         p.data.display();
     }
}

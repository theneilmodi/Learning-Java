
public class Game
{
  public static void main(){
      
     /*
        Deck deck = new Deck();
        for (int suit = 1; suit <= 4; suit++) {
            for (int rank = 1; rank <= 13; rank++) {
                Card card = deck.getCard(suit, rank);
                System.out.format("%s of %s%n",
                    card.rankToString(card.getRank()),
                    card.suitToString(card.getSuit()));
            }
        }
        */
       Card c1 = new Card(1,3);
       cardToString(c1);
    }
    
}

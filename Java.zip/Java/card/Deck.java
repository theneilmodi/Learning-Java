

public class Deck
{
    // instance variables - replace the example below with your own
    public static int numSuits = 4;
    public static int numRank = 13;
    public static int numCard = numSuits*numRank;
    
    public Card[][] cards;
    
    public Deck()
    {
        cards = new Card[numSuits][numRank];
        
        for(int suit = 1; suit<=4; suit++){
            for(int rank = 1; rank<=13; rank++){
                cards[suit-1][rank-1] = new Card(rank, suit);
            }
        }
    }
    
    public Card getCard(int suit, int rank){
        
        return cards[suit-1][rank-1];
    }

    
}

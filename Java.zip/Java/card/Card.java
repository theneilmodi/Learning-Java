
public class Card
{
    public final int rank;
    public final int suit;
    

    public Card(int rank, int suit)
    {
        assert isValidRank(rank);
        assert isValidSuit(suit);
        
        this.rank = rank;
        this.suit = suit;
    }

    public int getSuit(){
        return suit;
    }
    
     public int getRank(){
        return rank;
    }
    
     public static boolean isValidRank(int rank) {
        return 1 <= rank && rank <= 13;
    }

    public static boolean isValidSuit(int suit) {
        return 1 <= suit && suit <= 4;
    }
    
    public static String rankToString(int rank){
        switch (rank){
            case 1:
                return "Ace";
            case 2:
                return "Two";  
            case 3:
                return "Three";  
            case 4:
                return "Four";  
            case 5:
                return "Five"; 
            case 6:
                return "Six";
            case 7:
                return "Seven";
            case 8:
                return "Eight";
            case 9:
                return "Nine";
            case 10:
                return "Ten";
            case 11:
                return "Jack";
            case 12:
                return "Queen";
            case 13:
                return "King";
            default:   
                return null;
        }
    }
    
      public static String suitToString(int suit) {
        switch (suit) {
        case 1:
            return "Diamonds";
        case 2:
            return "Clubs";
        case 3:
            return "Hearts";
        case 4:
            return "Spades";
        default:
            return null;
        }    
    }
    
    public static String cardToString(Card x){
        
        return x.rankToString(x.getRank()) + " of " + x.suitToString(x.getSuit());
    }
}

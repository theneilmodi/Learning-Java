public class OfficeProgram
{
  public static void main(String[] args)
  {
     Employee e = new Employee("Employee",10000);
     Manager m = new Manager("Manager", 30000, "Fiat");
     Driver d = new Driver("Driver", 15000, 14);
     
     e.display();
     m.display();
     d.display();
     
     System.out.println("\n--------- NOW WE WILL USE BASE CLASS REFERENCE ONLY --------");
     
     Employee f, g, h;
     f = e; // base class reference can refer to
     g = m; // a derived object but not the other 
     h = d; // way round
            
     f.display(); //error if display is not defined in employee class
     g.display(); // if display is present in both Manager and Employee 
     h.display(); // it is the Manager's version which is called!
                  // This is dynamic or run time polymorphism
     System.out.println("\n--------- typecasted employee to manager explicitly --------");                
     Manager q = (Manager) g;
     q.display();
     
     System.out.println("\n--------- I can use base class reference everytime --------");                
     Employee r = new Manager("Manager2", 35000, "Volvo");
     r.display();
                  
     
     
  }
}

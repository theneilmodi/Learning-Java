public class Driver extends Employee
{
   int exp;
   
   public Driver(String n, double sal, int xp)
   { 
     super(n, sal);
     exp = xp;
    }
    
    public void display()
    {
      System.out.println("Driver's Display Function");
      System.out.println("Name = " + name);
      System.out.println("Salary = " + salary);
      System.out.println("Experience = " + exp + " years");
      System.out.println("------------------");
    }
}

public class Manager extends Employee
{
  String car;
  
  public Manager(String n, double s, String c)
  {
    super(n, s); // creates the base Employee object
    car = c;
  }
  
  public void printGrade()
  { if (salary > 20000)
      System.out.println(name + " is a Grade 1 manager");
    else 
      System.out.println(name + " is a Grade 2 manager");
  }
  
  public void display()
  {   
    System.out.println("This is the manager's display function");
    System.out.println("Name = " + name);
    System.out.println("Salary = " + salary);
    System.out.println("Car = " + car);    
    System.out.println("------------------"); 
  }      
  
}

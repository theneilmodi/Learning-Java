
public class Employee
{
  String name;
  double salary;
  
  public Employee(String n, double sal)
  { name = n;
    salary = sal;
  }
   
  public void display()
  {
    System.out.println("Name = " + name);
    System.out.println("Salary = " + salary);
    System.out.println("------------------");
  }
  
  public void incrementSal()
  {  salary = salary + 0.05*salary;
  }
 
}

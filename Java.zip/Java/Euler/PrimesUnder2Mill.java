

public class PrimesUnder2Mill
{
    
    public static void main(){
       
        long sum = 0;
        
        for(int x = 1; x<2000000; x++){
            
            if(isPrime(x)){
                
                sum = x + sum;
            }
        }
        
     System.out.println(sum);
        
    }
    
     public static boolean isPrime(int x){
            
           for(int i=2;i<=Math.sqrt(x); i++){
               
               if(x % i == 0){
                   return false;
                }
            }
            
            if(x!=1) return true;
            else return false;
    
    }
    
    
}

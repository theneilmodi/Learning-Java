
/**
 * Write a description of class Problem4 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Problem4
{
    public static void main(){
        
        int first = 999;
        int second = 999;
        int product = 0;
        
     for(int k = first; k >= 992; k--)  { 
        for(int i = second; i >= 912; i--){
            product = k*i;
            if(isPalindrome(product)) System.out.println(k + "*" + i + " = " + product);
        }
      } 
      
      
    }
    
    public static boolean isPalindrome(int num){

        String x = String.valueOf(num);
        
        if(x.substring(0,1).equals(x.substring(5,6)) && x.substring(1,2).equals(x.substring(4,5)) && x.substring(2,3).equals(x.substring(3,4))){
            return true;
        }
        else return false;
        
       
       
    }
}



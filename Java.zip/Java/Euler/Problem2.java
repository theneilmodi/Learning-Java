

public class Problem2
{
    public static void main(){
        
       long fibo1=1, fibo2=1, fibonacci=1, sum=0;
       
        while(fibonacci < 4000000){
            fibonacci = fibo1 + fibo2; 
                if(fibonacci % 2 == 0) sum += fibonacci;
            fibo1 = fibo2;
            fibo2 = fibonacci;
 
        }
        
        System.out.println(sum);
  }
}

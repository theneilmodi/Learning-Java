
/**
 * Write a description of class trial here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class trial
{
    public static void main(){
        
        System.out.println(4%3);
        
    }
}

import java.awt.FlowLayout; // Layout
import javax.swing.JFrame; // Basic Window
import javax.swing.JLabel; // Text and images and stuff


public class FrameOther extends JFrame
{
    
    private JLabel item1;
    
    
    public FrameOther(){
        
      super("Title Bar");  // title
      setLayout(new FlowLayout()); // layout
      
      item1 = new JLabel("this is a sentence"); // text
      item1.setToolTipText("Hover show"); // hover
      add(item1);
      
    }
    
}

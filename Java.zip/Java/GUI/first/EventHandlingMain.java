import javax.swing.JFrame;

public class EventHandlingMain
{
    // instance variables - replace the example below with your own
    public static void main(String[] args){
        
        EventHandling obj = new EventHandling();
        obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        obj.setSize(350,200);
        obj.setVisible(true);
        
    }
}

import javax.swing.JFrame; // basic window


public class Frame
{
    public static void main(String[] args){
        
        FrameOther bucky = new FrameOther();
        bucky.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        bucky.setSize(275,180);
        bucky.setVisible(true);
        
    }
}

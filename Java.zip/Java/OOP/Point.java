/*
 * Every point has a x coordinate and a y coordinate
 * Spose capital a is a point object 
 * A.reflect('x'); ---- > x axis, y axis, and Origin
 * A.distanceTo(B); ----> distance from A to B
 * A.midpoint(B); -----> midpoint of AB
 * 
 * if(A.equals(B)) return true;
 * 
 * A.slope(B); 
 * 
 * Point.areCollinear(A,B,C) return true
 *  slope of A and B == slope of b and c
 *  
 * if(Point.triangle(A,B,C)) return true if they can form a triangle, collinaer is false
 * 
 * if(Point.parallelogram(A,B,C,D)) midpoint AC == midpoint BD
 * 
 * if(A.liesInside(B,C,D)) return true if inside the triangle
 * 
 */

public class Point
{
    double x;
    double y;
    
    public Point(){
        x = 0;
        y = 0;
    }
    
    public Point(double j, double k){
      x = j;
      y = k;
    }
    
    public void display(){
        
        System.out.println("(" + x + "," + y + ")");
    }
    
    public void reflect(char axis){
        
        if(axis == 'x') {
            
          System.out.println("Reflection across x axis: (" + x + "," + -y + ")");  
            
        }else if(axis == 'y'){
            
            System.out.println("Reflection across y axis: (" + -x + "," + y + ")");  
            
        }else System.out.println("Error");
               
    }
    
    
    public double distanceTo(Point B){
     
        return Math.sqrt((this.x-B.x)*(this.x-B.x)+(this.y-B.y)*(this.y-B.y));
        
    }
    
    public Point midpoint(Point B){
     
        return new Point((this.x + B.x)/2,(this.y + B.y)/2);
    }
    

    
    public boolean equals(Point B){
     
       if(this.x == B.x && this.y == B.y)
            return true;
       else 
            return false;
    }
    
    public double slope(Point B){
        
        return (B.y-this.y)/(B.x-this.y);
    }
    
    public static boolean areCollinear(Point A, Point B, Point C){
        
        if(A.slope(B) == B.slope(C))
            return true;
        else
            return false;
    }
    
    public static boolean triangle(Point A, Point B, Point C){
        
        if(!Point.areCollinear(A,B,C))
            return true;
        else 
            return false;
    }
    
    public static boolean parallelogram(Point A, Point B, Point C, Point D){
        
        if(A.midpoint(C).equals(B.midpoint(D))) 
            return true;
        else 
            return false;
        
    }
    
    public boolean isInside(Point A, Point B, Point C){
        
        // returns true if this point is inside the triangle ABC
    }
}
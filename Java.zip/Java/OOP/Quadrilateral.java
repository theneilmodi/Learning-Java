
public class Quadrilateral
{
    Point A;
    Point B;
    Point C;
    Point D;
    
    public Quadrilateral(Point k, Point l, Point m, Point n){
        
        if(!(Point.areCollinear(k, l, m) || Point.areCollinear(k,l,n)
        || Point.areCollinear(k,m,n) || Point.areCollinear(l,m,n)))
          
        {
           
          A = new Point(k.x,k.y);  
          B = new Point(l.x,l.y); 
          C = new Point(m.x,m.y);  
          D = new Point(n.x,n.y);  
        }
        
        public double area(){
           
            
        }
        /* length of AB
         * length of BC   --- FIND THE AREA OF THIS TRIANGLE
         * Length of AC
         * Length of CD   --- FIND THE AREA OF THIS TRIANGLE
         * Length of DA
         * 
         * add 2 areas
         * 
         * 
         */
        
        public boolean isParallelogram(){
          
            /*Compare slopes of opposite sides
             * return true if  parallelogram
             * 
             */
            
        }
        
        public boolean isRhombus(){
            
            /* Rhombus is a parallelogram with all sides equal
             */
            
        }
        
        public boolean rightAngled(){
            
            // returns true if square or rect AC == BD, then right angled
            
        }
        
        
    }
    
}

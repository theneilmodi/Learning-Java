
public class PointProgram
{
    public static void main(String [] args){
        
        Point A = new Point(2,3);
        Point B = new Point(7,9);
        Point C = new Point(8,1);
        Point D = new Point(5,5);
        
        
        
        A.reflect('x');
        
        System.out.println(A.distanceTo(B));
        
        A.midpoint(B).display();
        
        if(A.equals(B)) System.out.println("A and B are the same point");
        
        System.out.println(A.slope(B)); 
        
        if(Point.areCollinear(A,B,C)) System.out.println("A,B,C are collinear");
        
        if(Point.triangle(A,B,C)) System.out.println("A,B,C can form a triangle");
        
        if(Point.parallelogram(A,B,C,D)) System.out.println("A,B,C,D forms a parallelogram");
        
        
        
        
    }

}

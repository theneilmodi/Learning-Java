
public class StackList
{

LNode head;

public void push(int d){

    // adds to beginning of the list
    
    head = new LNode(d,head);

}


public void printall(){


    LNode p = head;

    while(p != null){

        System.out.println(p.data);
         p = p.next;
        }

}

public void pop(){
//deletes node at top of the list

if(head != null) head = head.next;


}

public void peak(){

if(head != null) System.out.println(head.data);
else System.out.println("ERROR");
}


public void count(int d){

int counter = 0;

    LNode p = head;

    while(p != null){

       if(p.data == d) counter++;
        
         p = p.next;
        }

if(counter > 0) System.out.println(counter);
else System.out.println("Not found");
}

public void maxMin(){

if(head == null) System.out.println("List is empty");
else{

    LNode p = head.next;
    int max = head.data;
    int min = head.data;

    while(p != null){

       if(p.data > max) max = p.data;
       
       if(p.data < min) min = p.data;
        
       p = p.next;
    }

        System.out.println(max + " " + min);
    }
}

}

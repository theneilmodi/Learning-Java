
public class LNode
{
 int data;
 LNode next;
 
 public LNode(int d, LNode l){
     
     data = d; 
     next = l;
     
     
    }
   
}

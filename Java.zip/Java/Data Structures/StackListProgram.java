
public class StackListProgram
{
    
    public static void main(String [] args){
    StackList l = new StackList();
    
    l.push(5);
    l.push(3);
    l.push(7);
    
    l.printall();
    l.maxMin();
}
}

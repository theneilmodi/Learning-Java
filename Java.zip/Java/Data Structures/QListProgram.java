
public class QListProgram
{
    public static void main(){
        
     QList q = new QList();
     
     q.add(1);
     q.add(2);
     q.add(3);   
     
     q.printall();
    q.maxMin();
    }
}


public class SortedListProgram
{
    public static void main(){
        
     SortedList q = new SortedList();
     
     q.add(1);
     q.add(2);
     q.add(3);   
     q.add(4);
     q.delete(1);
     
     q.printall();
     
     
    }
}

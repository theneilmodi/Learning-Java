
public class NewForLoop
{
    public static void main(){
     
        Integer num = new Integer(25);
        E num2; 
    }
}
